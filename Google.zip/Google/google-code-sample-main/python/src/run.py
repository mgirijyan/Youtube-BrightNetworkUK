"""A youtube terminal simulator."""

# I was struggling to run my code properly as I was
# having issues with the importing of my files.

from fix import video_player
from fix import command_parser


if __name__ == "__main__":
    print("""Hello and welcome to YouTube, what would you like to do?
    Enter HELP for list of available commands or EXIT to terminate.""")
    video_player = video_player()
    parser = command_parser.CommandParser(video_player)
    while True:
        command = input("YT> ")
        if command.upper() == "EXIT":
            break
        try:
            parser.execute_command(command.split())
        except command_parser.CommandException as e:
            print(e)
    print("YouTube has now terminated its execution. "
          "Thank you and goodbye!")
